# LuaNode for STM32L4 serial chip
---------------------------------------

This part is ongoing, coming soon!
