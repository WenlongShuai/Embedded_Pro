## HOW TO FLASH

Use either the Espressif flash_download_tools or esptool.py to flash the firmware.

The start address is 0x1000
