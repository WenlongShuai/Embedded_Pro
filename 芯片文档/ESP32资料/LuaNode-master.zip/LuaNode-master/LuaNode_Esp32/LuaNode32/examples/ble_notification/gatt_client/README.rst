ESP-IDF GATT CLIENT demo
========================

This is the demo for user to use ESP_APIs to create a GATT Client.

