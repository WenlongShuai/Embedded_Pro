# Build

* Setup IDF_PATH by the following command: `export IDF_PATH=/your_esp_idf_path`
* Setup toolchain by: `export PATH=/your_esp32_toolchain_path:$PATH`
* Execute `make`

You can download the nRF51822 sources from the following 
link: https://github.com/Nicholas3388/nRF51822_ESP32_communicate

Build the nRF51822 project within `Keil uVersion4`.
