Download the APP from the following project: https://github.com/Nicholas3388/LuaNode_BLE_Client
