#ifndef __BLE_H__
#define __BLE_H__

// prototype
void ble_init(void);
void ble_client_app_register(void);
void ble_start_scanning(void);

#endif
