#ifndef __UTILS_H__
#define __UTILS_H__

int str2num(const char *str, int len);

#endif
