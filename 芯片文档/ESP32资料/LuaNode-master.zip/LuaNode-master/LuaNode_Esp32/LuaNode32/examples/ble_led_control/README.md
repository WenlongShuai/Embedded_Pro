# HOW TO BUILD

To build this sample, setup IDF_PATH by the following command `export IDF_PATH=/your_idf_path`. 
And setup your toolchain path by the following comman `export PATH=/your_tool_chain_path:$PATH`. 
Then change your directory to `client` or `server` and execute `make` to generate firmware.
