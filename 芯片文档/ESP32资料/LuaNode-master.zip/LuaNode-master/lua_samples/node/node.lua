-- methods same as nodemcu

node.heap();	-- print heap 

node.restart();	-- restart chip
