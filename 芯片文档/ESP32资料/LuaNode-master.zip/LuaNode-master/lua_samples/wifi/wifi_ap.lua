-- set wifi softap mode

wifi.setmode(wifi.SOFTAP);
wifi.start();

