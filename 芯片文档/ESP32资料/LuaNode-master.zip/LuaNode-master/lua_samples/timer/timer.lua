-- timer
-- tmr.delay(us) 

tmr.delay_us(1000000);  -- Delay 1000000us, and then output hello
print("hello");

tmr.delay_ms(1000);		-- delay 1000ms
print("hello");

tmr.delay(1);			-- delay 1s
print("hello");

tmr.now(); -- Output timestamp

