-- utils module
print(utils.leapyear(2016))	-- is the input year leap year?

str = "hello"
encodeStr = utils.base64_encode(str)
decodeStr = utils.base64_decode(encodeStr)