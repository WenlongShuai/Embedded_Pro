#include "headfile.h"
int16_t int16_constrain(int16_t Value, int16_t minValue, int16_t maxValue);
float fp32_constrain(float Value, float minValue, float maxValue);
#define my_abs(a) (a>0?a:-a)